# Happy Diwali

A Pen created on CodePen.io. Original URL: [https://codepen.io/Itxshakil/pen/aLPYEJ](https://codepen.io/Itxshakil/pen/aLPYEJ).

Fireworks with Sound